const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('./db/config');
const User = require('./db/User');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const user = new User({ name, email, password });
    await user.save();
    user = user.toObject();
    delete user.password;
    res.send(user);
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

app.post("/login",async(req,resp)=>{
  console.log(req.body);
  if(req.body.password && req.body.email)
  {
    let user =await User.findOne(req.body).select("-password");
    if(user)
    {
      resp.send(user);
    }
    else{
      resp.send("NO user found");
    }
  }
  else{
    resp.send("NO user found");
  }
 
 
})

mongoose.connect('mongodb://localhost:27017/e-comm', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');

  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
});