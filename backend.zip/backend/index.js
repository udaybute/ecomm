const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const Jwt = require('jsonwebtoken');
const JwtKey = 'e-comm';
require('./db/config');
const User = require('./db/User');
const Product = require("./db/Product");
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const user = new User({ name, email, password });
    await user.save();
    const userObject = user.toObject();
    delete userObject.password;
    Jwt.sign({userObject},JwtKey,{expiresIn:"2h"},(err,token)=>{
      if(err)
      {
        resp.send({userObject:"something went wrong , please again later"})
      }
      res.send({userObject, auth:token});
    })
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

app.post('/login', async (req, res) => {
  console.log(req.body);
  if (req.body.password && req.body.email) {
    let user = await User.findOne(req.body).select('-password');
    if (user) {
      Jwt.sign({user},JwtKey,{expiresIn:"2h"},(err,token)=>{
        if(err)
        {
          resp.send({result:"something went wrong , please again later"})
        }
        res.send({user, auth:token});
      })
      
    } else {
      res.send('No user found');
    }
  } else {
    res.send('No user found');
  }
});

app.post("/product",varifyToken, async (req, resp) => {
  let product = new Product(req.body);
  let result = await product.save();
  resp.send(result);
})

app.get("/products", varifyToken, async (req, resp) => {
  let products = await Product.find();
  if (products.length > 0) {
    resp.send(products)
  }
  else {
    resp.send({ result: "no products found" });
  }

})

app.delete(("/product/:id"), varifyToken,async (req, resp) => {
  let result = await Product.deleteOne({ _id: req.params.id })
  resp.send(result);
});

app.get("/product/:id",varifyToken, async (req, resp) => {
  let result = await Product.findOne({ _id: req.params.id });
  if (result) {
    resp.send(result);
  }
  else {
    resp.send({ result: "No record Found" });
  }
})

app.put("/product/:id",varifyToken, async (req, resp) => {
  let result = await Product.updateOne(
    { _id: req.params.id },
    {
      $set: req.body
    }
  )
  resp.send(result);
})


app.get("/search/:key", varifyToken, async (req, resp) => {
  let result =await Product.find({

    "$or": [
      { name: { $regex: req.params.key } },
      {company:{$regex:req.params.key}},
      {category:{$regex:req.params.key}}
    ]
  });
  resp.send(result)
})

app.get('/user', varifyToken, async (req, resp) => {
  try {
    const token = req.headers['authorization'];
    const decoded = Jwt.verify(token.split(' ')[1], JwtKey);
    const user = await User.findOne({ _id: decoded.user._id }).select('-password');
    resp.send(user);
  } catch (error) {
    console.error(error);
    resp.status(500).send('Server Error');
  }
});

app.put('/user', varifyToken, async (req, resp) => {
  try {
    const token = req.headers['authorization'];
    const decoded = Jwt.verify(token.split(' ')[1], JwtKey);
    const userId = decoded.user._id;
    
    const { name, email, password } = req.body;
    await User.findByIdAndUpdate(userId, { name, email, password });
    
    resp.send('User details updated successfully');
  } catch (error) {
    console.error(error);
    resp.status(500).send('Server Error');
  }
});

//middleware - difference between middleware and funciton is inside middleware parameter you 
// have to give atleast three paramter 
function varifyToken(req,resp,next){
  let token = req.headers['authorization'];
  if(token)
  {
    token = token.split(' ')[1]; //extracting token from authorization 
    console.warn("middleware called if ",token);
  Jwt.verify(token,JwtKey, (err, valid)=>{
    if(err)
    {
      resp.status(401).send({result:"please provide add valid token"});
    }
    else{
     next();
    }
  })
  }
  else{
    resp.status(403).send({result:"please add token with header"});
  }
  
}

mongoose.connect('mongodb://localhost:27017/e-comm', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');

  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
});