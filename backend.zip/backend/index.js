const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('./db/config');
const User = require('./db/User');
const Product = require("./db/Product");
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const user = new User({ name, email, password });
    await user.save();
    const userObject = user.toObject();
    delete userObject.password;
    res.send(userObject);
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

app.post('/login', async (req, res) => {
  console.log(req.body);
  if (req.body.password && req.body.email) {
    let user = await User.findOne(req.body).select('-password');
    if (user) {
      res.send(user);
    } else {
      res.send('No user found');
    }
  } else {
    res.send('No user found');
  }
});

app.post("/product", async (req, resp) => {
  let product = new Product(req.body);
  let result = await product.save();
  resp.send(result);
})

app.get("/products", async (req, resp) => {
  let products = await Product.find();
  if (products.length > 0) {
    resp.send(products)
  }
  else {
    resp.send({ result: "no products found" });
  }

})

app.delete(("/product/:id"), async (req, resp) => {
  let result = await Product.deleteOne({ _id: req.params.id })
  resp.send(result);
});

app.get("/product/:id", async (req, resp) => {
  let result = await Product.findOne({ _id: req.params.id });
  if (result) {
    resp.send(result);
  }
  else {
    resp.send({ result: "No record Found" });
  }
})

app.put("/product/:id", async (req, resp) => {
  let result = await Product.updateOne(
    { _id: req.params.id },
    {
      $set: req.body
    }
  )
  resp.send(result);
})









app.get("/search/:key", async (req, resp) => {
  let result =await Product.find({

    "$or": [
      { name: { $regex: req.params.key } },
      {company:{$regex:req.params.key}},
      {category:{$regex:req.params.key}}
    ]
  });
  resp.send(result)
})

mongoose.connect('mongodb://localhost:27017/e-comm', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');

  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
});