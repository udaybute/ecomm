import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Carousel from './Carousel';
import './css/productlist.css';

const ProductList = () => {
  const [products, setProducts] = useState([]);

  const getProducts = async () => {
    try {
      const response = await fetch('http://localhost:5000/products', {
        headers: {
          authorization: `bearer ${JSON.parse(localStorage.getItem('token'))}`
        }
      });
      const result = await response.json();
      setProducts(result);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getProducts();
  }, []);

  const deleteProduct = async (id) => {
    try {
      const response = await fetch(`http://localhost:5000/product/${id}`, {
        method: 'DELETE',
        headers: {
          authorization: `bearer ${JSON.parse(localStorage.getItem('token'))}`
        }
      });
      const result = await response.json();
      if (result) {
        toast.success('Record is Deleted Successfully ...');
        getProducts();
      }
    } catch (error) {
      console.error(error);
    }
  };

  const searchHandle = async (event) => {
    let key = event.target.value;
    if (key) {
      try {
        const response = await fetch(`http://localhost:5000/search/${key}`, {
          headers: {
            authorization: `bearer ${JSON.parse(localStorage.getItem('token'))}`
          }
        });
        const result = await response.json();
        if (result) {
          setProducts(result);
        }
      } catch (error) {
        console.error(error);
      }
    } else {
      getProducts();
    }
  };

  return (
    <div>
      <ToastContainer />
      <Carousel />
      <h3 className='text-center text-dark m-2'>Product List</h3>

      <form className="d-flex p-2 m-auto mb-5 w-50 align-content-center">
        <input className="form-control me-2" onChange={searchHandle} type="search" placeholder="Search" aria-label="Search" />
        <button className="btn btn-outline-success" type="submit">Search</button>
      </form>

      <div className="row">
        {products.length > 0 ? (
          products.map((item, index) => (
            <div key={index} className="cardcontainer col-lg-3 col-md-6 m-auto border mb-4 shadow p-5 card-margin">
              <div className="card">
                <img
                  src={item.imagelink}
                  className="img img-fluid w-75 mt-2 m-auto card-img-zoom"
                  alt={item.name}
                />
                <div className="card-body">
                  <h5 className="card-title">{item.name}</h5>
                  <p className="card-text">{item.description}</p>
                  <p className="card-text">Category: {item.category}</p>
                  <h6 className="card-text">${item.price}</h6>
                  <div className="d-grid gap-2">
                    <button className="btn btn-success" type="button">
                      <Link to={'/update/' + item._id} className='text-decoration-none text-dark'> Update Product </Link>
                    </button>
                    <button
                      onClick={() => deleteProduct(item._id)}
                      className="btn btn-danger"
                      type="button"
                    >
                      Delete Product
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <h1 className='text-center p-5'>No result found </h1>
        )}
      </div>
    </div>
  );
};

export default ProductList;