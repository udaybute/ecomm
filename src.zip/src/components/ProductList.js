import React, { useEffect, useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ProductList = () => {
  const [products, setProducts] = useState([]);

  const getProducts = async () => {
    let result = await fetch('http://localhost:5000/products');
    result = await result.json();
    setProducts(result);
  };

  useEffect(() => {
    getProducts();
  }, []);

  const deleteProduct = async (id) => {
    let result = await fetch(`http://localhost:5000/product/${id}`, {
      method: 'Delete'
    });
    result = await result.json();
    if (result) {
      toast.success('Record is Deleted Successfully ...');
      getProducts();
    }
  };

  console.warn(products);

  return (
    <div>
      <ToastContainer />
      <h2>Product List</h2>

      <div className="row">
        {products.map((item, index) => (
          <div key={index} className="col-lg-3 col-md-6 mb-4">
            <div className="card">
              <img
                src={item.image}
                className="card-img-top"
                alt={item.name}
                style={{ height: '200px', objectFit: 'cover' }}
              />
              <div className="card-body">
                <h5 className="card-title">{item.name}</h5>
                <p className="card-text">{item.description}</p>
                <p className="card-text">Category: {item.category}</p>
                <h6 className="card-text">${item.price}</h6>
                <div className="d-grid gap-2">
                  <button className="btn btn-primary" type="button">
                    Add to Cart
                  </button>
                  <button className="btn btn-success" type="button">
                    Buy Now
                  </button>
                  <button
                    onClick={() => deleteProduct(item._id)}
                    className="btn btn-danger"
                    type="button"
                  >
                    Delete Product
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductList;