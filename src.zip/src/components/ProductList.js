import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ProductList = () => {
  const [products, setProducts] = useState([]);

  const getProducts = async () => {
    let result = await fetch('http://localhost:5000/products');
    result = await result.json();
    setProducts(result);
  };

  useEffect(() => {
    getProducts();
  }, []);

  const deleteProduct = async (id) => {
    let result = await fetch(`http://localhost:5000/product/${id}`, {
      method: 'Delete'
    });
    result = await result.json();
    if (result) {
      toast.success('Record is Deleted Successfully ...');
      getProducts();
    }
  };

  console.warn(products);

  const searchHandle = async (event) =>{
    let key = event.target.value;
    if(key)
    {
      let result = await fetch(`http://localhost:5000/search/${key}`);
    result = await result.json();
    if(result)
    {
      setProducts(result);
    }
    }
    else{
      getProducts();
    }
  }

  return (
    <div>
      <ToastContainer />
      <h3 className='text-center text-dark m-2'>Product List</h3>
     
      <form class="d-flex p-2 m-auto mb-5 w-50 align-content-center">
        <input class="form-control me-2" onChange={searchHandle} type="search" placeholder="Search" aria-label="Search"/>
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>

      <div className="row">
        {
         products.length > 0 ? products.map((item, index) => (
          <div key={index} className="col-lg-3 col-md-6 mb-4">
            <div className="card">
              <img
                src={item.image}
                className="card-img-top"
                alt={item.name}
                style={{ height: '200px', objectFit: 'cover' }}
              />
              <div className="card-body">
                <h5 className="card-title">{item.name}</h5>
                <p className="card-text">{item.description}</p>
                <p className="card-text">Category: {item.category}</p>
                <h6 className="card-text">${item.price}</h6>
                <div className="d-grid gap-2">
                 
                  <button className="btn btn-success" type="button">
                   <Link to={'/update/'+item._id} className='text-decoration-none text-dark'> Update Product </Link>
                  </button>
                  <button
                    onClick={() => deleteProduct(item._id)}
                    className="btn btn-danger"
                    type="button"
                  >
                    Delete Product
                  </button>
                  <button className="btn btn-primary" type="button">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))
        : <h1 className='text-center p-5'>No result found </h1>
      }
      </div>
    </div>
  );
};

export default ProductList;