import React, { useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
const Nav = () => {
    const navigate = useNavigate();
    const auth = localStorage.getItem("user");
    return (
        <div>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#">Navbar</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <li><Link to="/" class="nav-link active" >Home</Link></li>
                            </li>

                            <li class="nav-item">
                                <li><Link to="/add" class="nav-link active" >Add Product</Link></li>
                            </li>

                            <li class="nav-item">
                                <li><Link to="/update" class="nav-link active" >Update Product</Link></li>
                            </li>

                            <li class="nav-item">
                                <li><Link to="/profile" class="nav-link active" >Profile</Link></li>
                            </li>

                            <li class="nav-item">
                                <li>
                                    { auth ? <Link to="/logout" class="nav-link active" >Logout</Link> :
                                        <Link to="/signup" class="nav-link active" >Sign Up</Link>
                                    }
                                </li>
                            </li>
                        </ul>
                        <form class="d-flex">
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                            <button class="btn btn-outline-success" type="submit">Search</button>
                        </form>
                    </div>
                </div>
            </nav>
        </div>
    )
}

export default Nav