import React, { useEffect, useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ProfileComponent = () => {
  const [userDetails, setUserDetails] = useState({
    name: '',
    email: '',
    password: ''
  });
  const [isEditable, setIsEditable] = useState(false);

  useEffect(() => {
    getUserDetails();
  }, []);

  const getUserDetails = async () => {
    try {
      const response = await fetch('http://localhost:5000/user', {
        headers: {
          Authorization: `Bearer ${JSON.parse(localStorage.getItem('token'))}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setUserDetails(data);
      } else {
        throw new Error('Failed to fetch user details');
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleInputChange = (event) => {
    setUserDetails({
      ...userDetails,
      [event.target.name]: event.target.value
    });
  };

  const handleUpdateClick = () => {
    setIsEditable(true);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch('http://localhost:5000/user', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${JSON.parse(localStorage.getItem('token'))}`
        },
        body: JSON.stringify(userDetails)
      });

      if (response.ok) {
        setIsEditable(false);
        toast.success('User details updated successfully');
      } else {
        throw new Error('Failed to update user details');
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <ToastContainer />

      <section className="vh-100" style={{ backgroundColor: '#9de2ff' }}>
        <div className="container py-5 h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col col-md-9 col-lg-7 col-xl-5">
              <div className="card" style={{ borderRadius: '15px' }}>
                <div className="card-body p-4">
                  <div className="d-flex text-black">
                    <div className="flex-shrink-0">
                      <img
                        src="https://wallpapers.com/images/high/bts-jungkook-undercut-vw4cfbc19zuxyktk.webp"
                        alt="Generic placeholder image"
                        className="img-fluid"
                        style={{ width: '180px', borderRadius: '10px' }}
                      />
                    </div>
                    <div className="flex-grow-1 ms-3">
                      <h5 className="mb-1">{userDetails.name}</h5>
                      <p className="mb-2 pb-1" style={{ color: '#2b2a2a' }}>
                        {userDetails.email}
                      </p>
                      <div
                        className="d-flex justify-content-start rounded-3 p-2 mb-2"
                        style={{ backgroundColor: '#efefef' }}
                      >
                        
                      </div>
                      {isEditable ? (
                        <form onSubmit={handleSubmit}>
                          <div className="mb-3">
                            <label htmlFor="name" className="form-label">
                              Name
                            </label>
                            <input
                              type="text"
                              className="form-control"
                              id="name"
                              name="name"
                              value={userDetails.name}
                              onChange={handleInputChange}
                            />
                          </div>
                          <div className="mb-3">
                            <label htmlFor="email" className="form-label">
                              Email
                            </label>
                            <input
                              type="email"
                              className="form-control"
                              id="email"
                              name="email"
                              value={userDetails.email}
                              onChange={handleInputChange}
                            />
                          </div>
                          <div className="mb-3">
                            <label htmlFor="password" className="form-label">
                              Password
                            </label>
                            <input
                              type="password"
                              className="form-control"
                              id="password"
                              name="password"
                              value={userDetails.password}
                              onChange={handleInputChange}
                            />
                          </div>
                          <button type="submit" className="btn btn-primary">
                            Update
                          </button>
                        </form>
                      ) : (
                        <div className="d-flex pt-1">
                          <button
                            type="button"
                            className="btn btn-outline-primary me-1 flex-grow-1"
                            onClick={handleUpdateClick}
                          >
                            Edit
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProfileComponent;