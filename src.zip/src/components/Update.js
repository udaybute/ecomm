import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useParams } from 'react-router-dom';

const Update = () => {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('');
  const [company, setCompany] = useState('');
  const [imagelink, setImage] = useState('');
  const [error, setError] = useState(false);
  const params = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    getProductDetails();
  }, []);

  const getProductDetails = async () => {
    console.log('params' + params);
    let result = await fetch(`http://localhost:5000/product/${params.id}`,{
        headers : {
            authorization : `bearer ${JSON.parse(localStorage.getItem('token'))}`
          }
    });
    result = await result.json();

    setName(result.name);
    setPrice(result.price);
    setCategory(result.category);
    setCompany(result.company);
    setImage(result.imagelink);
    console.log(result);
  };

  const updateProduct = async () => {
    console.log(name + ' ' + price + ' ' + category + ' ' + company + ' ' + imagelink);
  
    let result = await fetch(`http://localhost:5000/product/${params.id}`, {
      method: "put",
      body: JSON.stringify({ name, price, category, company, imagelink }), // Include imagelink in the request body
      headers: {
        'Content-Type': "application/json",
        authorization: `bearer ${JSON.parse(localStorage.getItem('token'))}`
      }
    });
  
    result = await result.json();
    console.warn(result);
    navigate("/");
  };

  return (
    <div>
      <ToastContainer />
      <form className="w-50 p-2 m-auto border border-1 mb-2">
        <h3 className="text-center">Update Product Page</h3>

        <div className="mb-3">
          <label htmlFor="name" className="form-label">
            Name
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
          />
          {error && !name && (
            <div id="errorfield" className="errorfield form-text text-danger">
              Please enter a valid name.
            </div>
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="price" className="form-label">
            Price
          </label>
          <input
            type="text"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            className="form-control"
            id="price"
            aria-describedby="price"
          />
          {error && !price && (
            <div id="errorfield" className="errorfield form-text text-danger">
              Please enter a valid price.
            </div>
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="category" className="form-label">
            Category
          </label>
          <input
            type="text"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="form-control"
            id="category"
            aria-describedby="category"
          />
          {error && !category && (
            <div id="errorfield" className="errorfield form-text text-danger">
              Please enter a valid category.
            </div>
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="company" className="form-label">
            Company
          </label>
          <input
            type="text"
            value={company}
            onChange={(e) => setCompany(e.target.value)}
            className="form-control"
            id="company"
            aria-describedby="company"
          />
          {error && !company && (
            <div id="errorfield" className="errorfield form-text text-danger">
              Please enter a valid company.
            </div>
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="imagelink" className="form-label">
            Image Link
          </label>
          <input
            type="text"
            value={imagelink}
            onChange={(e) => setImage(e.target.value)}
            className="form-control"
            id="imagelink"
            aria-describedby="imagelink"
          />
          {error && !imagelink && (
            <div id="errorfield" className="errorfield form-text text-danger">
              Please enter a valid Image link.
            </div>
          )}
        </div>

        <button type="button" onClick={updateProduct} className="btn btn-primary">
          Update
        </button>
      </form>
    </div>
  );
};

export default Update;