import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
        <h5>Footer</h5>
    </div>
  )
}

export default Footer