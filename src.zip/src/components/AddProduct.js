import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const AddProduct = () => {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('');
  const [company, setCompany] = useState('');
  const [error, setError] = useState(false);
  const navigate = useNavigate();

  const addProduct = async () => {
    if (!name || !price || !category || !company) {
      setError(true);
      toast.error('Please enter valid details');
      return;
    }

    const userId = JSON.parse(localStorage.getItem('user'))._id;

    console.log(name + ' ' + price + ' ' + category + ' ' + company + ' ' + userId);
    let result = await fetch('http://localhost:5000/product', {
      method: 'post',
      body: JSON.stringify({ name, price, category, company, userId }),
      headers: {
        'Content-Type': 'application/json'
      }
    });
    result = await result.json();
    console.warn(result);
    if (!error) {
      localStorage.setItem('user', JSON.stringify(result));
      navigate('/');
      toast.success('Product added successfully!');
    } else {
      toast.error('An error occurred while adding the product.');
    }
  };

  return (
    <div>
      <ToastContainer />
      <form className="w-50 p-2 m-auto border border-1 mb-2">
        <h3 className="text-center">Add Product Page</h3>

        <div className="mb-3">
          <label htmlFor="name" className="form-label">
            Name
          </label>
          <input
            type="text"
            onChange={(e) => setName(e.target.value)}
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
          />
          {error && !name && (
            <div id="errorfield" className="errorfield form-text text-danger">
              Please enter a valid name.
            </div>
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="price" className="form-label">
            Price
          </label>
          <input
            type="text"
            onChange={(e) => setPrice(e.target.value)}
            className="form-control"
            id="price"
            aria-describedby="price"
          />
          {error && !price && (
            <div id="errorfield" className="errorfield form-text text-danger">
              Please enter a valid price.
            </div>
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="category" className="form-label">
            Category
          </label>
          <input
            type="text"
            onChange={(e) => setCategory(e.target.value)}
            className="form-control"
            id="category"
            aria-describedby="category"
          />
          {error && !category && (
            <div id="errorfield" className="errorfield form-text text-danger">
              Please enter a valid category.
            </div>
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="company" className="form-label">
            Company
          </label>
          <input
            type="text"
            onChange={(e) => setCompany(e.target.value)}
            className="form-control"
            id="company"
            aria-describedby="company"
          />
          {error && !company && (
            <div id="errorfield" className="errorfield form-text text-danger">
              Please enter a valid company.
            </div>
          )}
        </div>

        <button type="button" onClick={addProduct} className="btn btn-primary">
          Submit
        </button>
      </form>
    </div>
  );
};

export default AddProduct;