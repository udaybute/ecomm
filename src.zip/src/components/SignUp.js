import React, { useEffect, useState } from 'react';
import { json, useNavigate } from 'react-router-dom';
import axios from 'axios';

const SignUp = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  useEffect(()=>{
    const auth = localStorage.getItem("user");
    if(auth)
    {
        navigate("/");
    }
})

  const collectData = async () => {
    console.warn(name + ' ' + email + ' ' + password);
    try {
      const response = await axios.post('http://localhost:5000/register', {
        name,
        email,
        password
      });
      console.warn(response.data);
      localStorage.setItem("user", JSON.stringify(response.data));
      navigate('/');
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <form className='w-50 p-2 m-auto border border-1 mb-2'>
        <div className='mb-3'>
          <label htmlFor='name' className='form-label'>
            Name
          </label>
          <input
            type='text'
            onChange={(e) => setName(e.target.value)}
            className='form-control'
            id='exampleInputPassword1'
          />
        </div>
        <div className='mb-3'>
          <label htmlFor='exampleInputEmail1' className='form-label'>
            Email address
          </label>
          <input
            type='email'
            onChange={(e) => setEmail(e.target.value)}
            className='form-control'
            id='exampleInputEmail1'
            aria-describedby='emailHelp'
          />
          <div id='emailHelp' className='form-text'>
            We'll never share your email with anyone else.
          </div>
        </div>
        <div className='mb-3'>
          <label htmlFor='exampleInputPassword1' className='form-label'>
            Password
          </label>
          <input
            type='password'
            onChange={(e) => setPassword(e.target.value)}
            className='form-control'
            id='exampleInputPassword1'
          />
        </div>
        <div className='mb-3 form-check'>
          <input
            type='checkbox'
            className='form-check-input'
            id='exampleCheck1'
          />
          <label className='form-check-label' htmlFor='exampleCheck1'>
            Check me out
          </label>
        </div>
        <button
          type='button'
          onClick={collectData}
          className='btn btn-primary'
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default SignUp;