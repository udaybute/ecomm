import './App.css';
import { BrowserRouter as Router, Routes, Link, Route }
  from "react-router-dom";
  import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Nav from './components/Nav';
import Footer from './components/Footer';
import SignUp from './components/SignUp';
import PrivateComponent from './components/PrivateComponent';
import Login from './components/Login';
import AddProduct from './components/AddProduct';
import ProductList from './components/ProductList';
import Update from './components/Update';
function App() {
  return (
    <div className="App">
      <ToastContainer />
      <Router>
        <Nav />
      
        <Routes>
          
          <Route element={<PrivateComponent/>}>
          <Route exact path="/" element={<ProductList />} />
          <Route exact path="add" element={<AddProduct/>} />
          <Route exact path="update/:id" element={<Update/>} />
          <Route exact path="logout" element={<h1>logout Page</h1>} />
          <Route exact path="profile" element={<h1>profile Page</h1>} />
          </Route>

          <Route exact path="signup" element={<SignUp/>} />
          <Route exact path="login" element={<Login/>} />
          <Route exact path="profile" element={<h1>profile Page</h1>} />
        </Routes>
        <Footer/>
      </Router>

    </div>
  );
}

export default App;
