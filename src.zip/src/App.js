import './App.css';
import { BrowserRouter as Router, Routes, Link, Route }
  from "react-router-dom";
import Nav from './components/Nav';
import Footer from './components/Footer';
import SignUp from './components/SignUp';
import PrivateComponent from './components/PrivateComponent';

function App() {
  return (
    <div className="App">\
      <Router>
        <Nav />
        <h1>E-Dashbord</h1>
        <Routes>
          
          <Route element={<PrivateComponent/>}>
          <Route exact path="/" element={<h1>Home Page</h1>} />
          <Route exact path="add" element={<h1>add Page</h1>} />
          <Route exact path="update" element={<h1>update Page</h1>} />
          <Route exact path="logout" element={<h1>logout Page</h1>} />
          <Route exact path="profile" element={<h1>profile Page</h1>} />
          </Route>

          <Route exact path="signup" element={<SignUp/>} />
          <Route exact path="profile" element={<h1>profile Page</h1>} />
        </Routes>
        <Footer/>
      </Router>

    </div>
  );
}

export default App;
